function x=retcolone(x);
% x=retcolone(x)  x=x(:);
x=x(:);