function varargout=retpermute(varargin);varargout=varargin;
% function [b,a,...]=retpermute(a,b,...);   b-->a   a-->b etc..  quelque soit la nature de a b,..
% See also:DEAL
