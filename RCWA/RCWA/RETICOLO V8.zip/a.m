function a(cal);
% cal 0:help  1: 1 D   2:2 D  3:tests
switch(cal);

case 0;
help exemple_general_1D;help exemple1_1D;help exemple_1D_pertes;help exemple2_1D;help exemple3_1D;help exemple5_1D;help exemple6_1D;help exemple9_1D;help exemple10_1D;help exemple11_1D;help exemple_1D_metal;
help exemple_general_conique;help exemple_conique_pertes;help exemple1_conique;
help exemple_general_2D;help exemple_2D_pertes;help exemple1_2D;help exemple2_2D;help exemple3_2D;help exemple5_2D;help exemple6_2D;help exemple7_2D;help exemple9_2D;help exemple10_2D;help exemple11_2D;help exemple8;
%help test1D2D;help test1D;

case 1;retio;
exemple_general_1D;
exemple_1D_pertes;
exemple1_1D;
exemple2_1D
exemple3_1D;
exemple5_1D;
exemple6_1D;
exemple9_1D;
exemple10_1D;
exemple11_1D;
exemple_1D_metal

exemple_general_conique;
exemple_conique_pertes;
exemple1_conique;

case 2;retio;
exemple_general_2D;
exemple_2D_pertes;
exemple1_2D;
exemple2_2D;
exemple3_2D;
exemple5_2D;
exemple6_2D;
exemple7_2D;
exemple9_2D;
exemple10_2D;
exemple11_2D;

exemple8;

case 3;retio;
test1D2D
test1D

end;